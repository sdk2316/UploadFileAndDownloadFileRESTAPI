export class City {
  id: number;
  name: string;
}
